<?php session_start();

?>
<html>
<head>
	<title>FucsiaStore</title>
	<link href="Estilos/estilo.css" rel="stylesheet" type="text/css">
	
	<link rel="stylesheet" type="text/css" href="../css/estilo.css" media="screen"/>
	<script type="text/javascript" src="javascript/jquery-1.7.1.min.js"> 
	
	</script> 
	<script type="text/javascript" src="javascript/funciones.js"> 
	</script> 
</head>
<body bgcolor="white">
<table align="center">
		<tr>
			<td><img src="Imagenes/fs.jpg" /></td>
		</tr>
		</table>
		
		<div id="sesion">
		<table align="center" border="2">
		<tr>
		<?php
		if(isset($_SESSION['user'])){
		echo "<td>Hola, ".$_SESSION['user']." / </td>";
		?>
		<td><a href="HTML/Usuario.php" target="marcoAba">Configuraci&oacute;n</a>
		/
		<a href="AccesoDatos/CerrarSesion.php">Salir</a></td>
		<?php
		}
		else{
			?>
		<tr>
		<td><a onclick="CargarPagina('HTML/login.php','contenedor');">Login</a>
		</td>
	
		<td><a onclick="CargarPagina('HTML/Usuario.php','contenedor');">Registrarse</a></td>
		</tr>
		<?php
		}
		?>
		<tr>
		</table>
	</div>
		
<div id="contenedor"></div>


		<iframe src="Html/inicio.html" name="marcoAba" scrolling="auto" frameborder="2" width="100%" height="60%"> 
		
		 <p>Su navegador de Internet no permite mostrar marcos.</p>
		</iframe>

	</body>
	
</html>