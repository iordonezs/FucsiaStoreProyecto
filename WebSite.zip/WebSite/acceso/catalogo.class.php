<?php 
// en las clases ingresa a la bd para insert, update, delete, y select
require('conexion.class.php');

class Catalogo{
 	var $con;
 	function Catalogo(){
 		$this->con=new DBManager;
 	}
	
	function Consulta_Color_T(){
		if($this->con->conectar()==true){
		
			$SQL="select * from color";
			echo $SQL;
			return mysql_query($SQL);
		}
	}
	
	//function Consulta_Color($Pruc, $color){
	//	if($this->con->conectar()==true){
		//select descri_color from producto, color where producto.codi_color=color.codi_color and codi_producto=1 
	//		$SQL="select * from producto, color  where producto.= '$Pruc' and codi_color = '$color'";
			//echo $SQL;
		//	return mysql_query($SQL);
	//	}
	//}
	
	function Consulta_Talla(){
		if($this->con->conectar()==true){
			$mySQL="select * from producto where codi_producto= '$Usuario' and codi_color = '$color' ";
			//echo $mySQL;
			return mysql_query($mySQL);
		}
	}
	
	function CerrarSesion(){
		session_start();
		$Usuario = $_SESSION['username'];
		session_destroy();
		
		Return 'Adios, $Usuario';
	}

	function CerrarConexion(){
		$this->con->desconectar();
	}
	
	function Producto_insert($arrProducto){
		if($this->con->conectar()==true){
			$SQL = "INSERT INTO producto(descri_producto, codi_color, codi_talla, codi_marca, codi_categoria, esta_producto, precio_producto, cant_producto)
				VALUES ('$arrProducto[0]','$arrProducto[1]','$arrProducto[2]',$arrProducto[3],'$arrProducto[4]','A','$arrProducto[5]')";
			//array($Nombre, $Apellido, $Cedula, $Edad, $Sexo, $Ciudad, $Usuario, $Pass);
			//VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
			//echo $SQL;
			$rsUsuario = mysql_query($SQL);
			
			return $rsUsuario;
		}
	}
	
	function Producto_update($arrProducto){
		if($this->con->conectar()==true){
			$SQL = "UPDATE producto SET
						descri_producto = '$arrProducto[1]', 
						codi_color = '$arrUsuario[2]', 
						codi_talla = '$arrUsuario[3]', 
						codi_marca = $arrUsuario[4], 
						codi_categoria = '$arrUsuario[5]', 
						esta_producto = 'A', 
						precio_producto = '$arrUsuario[6]', 
						cant_producto = '$arrUsuario[7]', 
					WHERE usu_codigo = $arrUsuario[0]";
			//$arrUsuario = array($id, $Nombre, $Apellido, $Cedula, $Edad, $Sexo, $Ciudad, $Usuario, $Pass);
			//VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
			//echo $SQL;
			$rsUsuario = mysql_query($SQL);
			
			return $rsUsuario;
		}
	}
	
}
?>