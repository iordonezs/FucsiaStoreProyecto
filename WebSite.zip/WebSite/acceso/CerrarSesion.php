<?php
session_start();

$Usuario = $_SESSION['user'];
session_destroy();

echo "<script language=javascript>
		alert('Adios, $Usuario')
		self.location='../index.php'
	</script>";

?>
