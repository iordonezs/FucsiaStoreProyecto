<?php 

require('conexion.class.php');

class Usuario{
 	var $con;
 	function Usuario(){
 		$this->con=new DBManager;
 	}
	
	function Iniciar_sesion($Usuario,$Contrasena){
		if($this->con->conectar()==true){
		//$sql="select *From usuario where user_nick='".$usu."' and user_psd=md5('".$pwd."')";
		$SQL = "select * from usuario where user_usuario='$Usuario' and pass_usuario = '$Contrasena'";
		
		$rsUsuario = mysql_query($SQL);
		
		return $rsUsuario;
		
		}
	}
	
	function Usuario_insert($arrUsuario){
		if($this->con->conectar()==true){
			$SQL =
			"INSERT INTO `usuario`(`codi_usuario`, `user_usuario`, `pass_usuario`, `esta_usuario`) 
			VALUES (0,'$arrUsuario[0]','$arrUsuario[1]','A')";
			//array($Nombre, $Apellido, $Cedula, $Edad, $Sexo, $Ciudad, $Usuario, $Pass);
			//VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
			//echo $SQL;
			$rsUsuario = mysql_query($SQL);
			
			return $rsUsuario;
		}
	}
	
	function Usuario_update($arrUsuario){
		if($this->con->conectar()==true){
			$SQL = "UPDATE usuario SET
						usu_nombre = '$arrUsuario[1]', 
						usu_apellido = '$arrUsuario[2]', 
						usu_cedula = '$arrUsuario[3]', 
						usu_edad = $arrUsuario[4], 
						usu_sexo = '$arrUsuario[5]', 
						ciu_codigo = $arrUsuario[6], 
						usu_user = '$arrUsuario[7]', 
						usu_pass = '$arrUsuario[8]', 
						usu_estado = 'A'
					WHERE usu_codigo = $arrUsuario[0]";
			//$arrUsuario = array($id, $Nombre, $Apellido, $Cedula, $Edad, $Sexo, $Ciudad, $Usuario, $Pass);
			//VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
			//echo $SQL;
			$rsUsuario = mysql_query($SQL);
			
			return $rsUsuario;
		}
	}

	function Consulta_Usuario($Usuario, $Pass){
		if($this->con->conectar()==true){
			$SQL="select * from usuario where usu_user= '$Usuario' and usu_pass = '$Pass'";
			//echo $SQL;
			return mysql_query($SQL);
		}
	}
	
	function Consulta_Ciudad_all(){
		if($this->con->conectar()==true){
			$mySQL="select * from ciudad";
			//echo $mySQL;
			return mysql_query($mySQL);
		}
	}
	
	function CerrarSesion(){
		session_start();
		$Usuario = $_SESSION['username'];
		session_destroy();
		
		Return 'Adios, $Usuario';
	}

	function CerrarConexion(){
		$this->con->desconectar();
	}
	
	
	
}
?>