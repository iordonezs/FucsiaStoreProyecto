


<?php
class DBManager{
    var $connect;
    var $BaseDatos;
    var $Servidor;
    var $usuario;
    var $clave; 
    function DBManager(){
        $this->BaseDatos = "u102764481_ingri";
        $this->Servidor = "mysql.nixiweb.com";
        $this->usuario = "u102764481_ingri";
        $this->clave = "@dm1n2014";
    }
	

    function conectar(){
		$con=@mysql_connect($this->Servidor,$this->usuario,$this->clave);
        if(!$con){
            echo "<h1> [:(] Error al conectar a la base de datos</h1>";
            exit();
        }
		
        /*mysql_query("SET NAMES 'utf8'",$con);*/
        if(!@mysql_select_db($this->BaseDatos,$con)){
            echo "<h1> [:(] Error al seleccionar la base de datos</h1>";
            exit();
        }
		//echo "conectado";
        $this->connect=$con;
        return true;
    }   
    function desconectar(){
        try{
            mysql_close($this->connect);
        }
        catch (Exception $e){
           echo 'Excepcion capturada: ', $e->getMessage(), "\n";
       }
    }
     
}
// $con =new DBManager;
// $resultado = $con->conectar();
// echo $resultado;
?>