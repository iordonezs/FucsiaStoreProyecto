<?php
session_start();
include "../conexion.php";
		$arreglo=$_SESSION['carrito'];
		$numeroventa=0;
		$re=mysql_query("select * detalle_factura from  order by secuencia_detfactura DESC limit 1") or die(mysql_error());	
		while (	$f=mysql_fetch_array($re)) {
					$numeroventa=$f['secuencia_detfactura'];	
		}
		if($numeroventa==0){
			$numeroventa=1;
		}else{
			$numeroventa=$numeroventa+1;
		}
		for($i=0; $i<count($arreglo);$i++){
			mysql_query("insert into detalle_factura (secuencia_detfactura, cant_detfactura,subtotal_detfactura,codi_producto) values(
				".$numeroventa.",
				'".$arreglo[$i]['Ima_Prod']."',
				'".$arreglo[$i]['Nomb_Prod']."',	
				'".$arreglo[$i]['Prec_Prod']."',
				'".$arreglo[$i]['Cantidad']."',
				'".($arreglo[$i]['Prec_Prod']*$arreglo[$i]['Cantidad'])."'
				)")or die(mysql_error());
		}
		unset($_SESSION['carrito']);


?>
<html>
<head>
<title>Venta Realizada</title>
<link rel="stylesheet" href="../css/style.css">

</head>
<body>

<header>        
<h1><b> HAPPY SHOP</b></h1>
<img id="logo" src="../images/logoama.png" alt="">  
    <nav> 
  	<ul> 	
		<li><a href="../index.php">Inicio</a> </li> 
    </ul>
  	
  </nav>
  
</header>

<center><h1>COMPRA EXITOSA  </BR> GRACIAS POR COMPRAR EN TU TIENDA "HAPPY SHOP" VUELVE PRONTO</h1> </center>

<center><a href="#"><img src="../images/imagencompra.jpg" alt=""></a></center>

</body>
</html>

