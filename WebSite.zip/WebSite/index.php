<?php session_start();
?>
<html>
<head>
	<title>Fucsia Store</title>
	<link href="Estilos/estilo.css" rel="stylesheet" type="text/css">
	
	<link rel="stylesheet" type="text/css" href="../css/estilo.css" media="screen"/>
	<script type="text/javascript" src="javascript/jquery-1.7.1.min.js"> 
	
	</script> 
	<script type="text/javascript" src="javascript/funciones.js"> 
	</script> 
</head>
<body bgcolor="white">
	<div id="sesion">
		<table align="center" border="2">
		<tr>
		<?php
		if(isset($_SESSION['user'])){
		echo "<td>Hola, ".$_SESSION['user']." / </td>";
		?>
		<td><a href="HTML/usuario.php" target="marcoAba">Configuraci&oacute;n</a>
		/
		<a href="acceso/cerrarsesion.php">Salir</a></td>
		<?php
		}
		else{
			?>
			<tr>
			<td><a onclick="CargarPagina('HTML/login.php','contenedor');">Login</a>
			</td>
		
			<td><a onclick="CargarPagina('HTML/usuario.php','contenedor');">Registrarse</a></td>
			</tr>
			<?php
		}
		?>
		<tr>
		</table>
	</div>
		<table align="center">
			<tr>
			
				<td><img src="Imagenes/fs.jpg" /></td>
			</tr>
		</table>
		
		<table  width="1000" height="50" align="center">
			<tr>
				<td align="center"> <font color="white"><a href="HTML/inicio.html" target="marcoAba">INICIO</a></td>
				<td align="center"> <font color="white"><a href="HTML/ofertas.html" target="marcoAba">OFERTAS</a></td>
				<td align="center"> <font color="white"><a href="HTML/catalogo.html" target="marcoAba">CAT&AacuteLOGO </a></td>
				<td align="center"> <font color="white"><a href="HTML/acercade.html" target="marcoAba">ACERCA DE</a></td>
				<td align="center"> <font color="white"><a href="HTML/contactanos.html" target="marcoAba">CONT&Aacute;CTANOS</a></td>
				<?php if(isset($_SESSION['user'])){?>
				<td align="center"> <font color="white"><a href="HTML/mantenimiento.html" target="marcoAba">MANTENIMIENTO</a></td>
				<?php }?>
				<br>
				
			</tr>
		</table>
		

<div id="contenedor"></div>
		

		<iframe src="Html/inicio.html" name="marcoAba" scrolling="auto" frameborder="2" width="100%" height="60%"> 
		
		 <td><img src="../Imagenes/fuscia.jpg"/></td>
		 <p>Su navegador de Internet no permite mostrar marcos.</p>
		</iframe>

	</body>
	
</html>