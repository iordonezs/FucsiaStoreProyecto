function ValidarIngreso(formulario){ 

	if (formulario.txt_nombre.value=="") {
		window.alert("Debe introducir su nombre");
		formulario.txt_nombre.focus();
		return false;
	}

	if (formulario.txt_ciudad.value=="") {
		window.alert("Debe introducir su ciudad");
		formulario.txt_ciudad.focus();
		return false;
	}

	if (formulario.txt_email.value=="") {
		window.alert("Debe introducir su email");
		formulario.txt_email.focus();
		return false;
	}

	if (formulario.txt_asunto.value=="") {
		window.alert("Debe introducir el asunto");
		formulario.txt_asunto.focus();
		return false;
	}
   
    if (formulario.txt_mensaje.value=="") {
		window.alert("Debe introducir su mensaje");
		formulario.txt_mensaje.focu();
		return false;
	}
   
    return true
}

function EnviarMensaje(formulario){
    if(ValidarIngreso(formulario)==true){
	window.alert('Mensaje Enviado');
    }  else{window.alert('Mensaje no Enviado');}  
} 





function CargarPagina(pagina,contenedor){
    document.getElementById(contenedor).innerHTML = "<div align='center'><p><img src='imagenes/loading.gif'/> </p><p>Cargando Pagina...</p></div>";
    $.ajax({
            url: pagina,
            type: 'GET',
            success: function(datos){
                $("#contenedor").html(datos);
                }
           });
}