-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-09-2014 a las 23:42:54
-- Versión del servidor: 5.6.16
-- Versión de PHP: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `fucsia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cab_factura`
--

CREATE TABLE IF NOT EXISTS `cab_factura` (
  `codi_cabfactura` int(11) NOT NULL AUTO_INCREMENT,
  `subtotal_cabfactura` decimal(4,2) NOT NULL,
  `IVA_cabfactura` decimal(4,2) NOT NULL,
  `total_cabfactura` decimal(4,2) NOT NULL,
  `esta__cabfactura` int(11) NOT NULL,
  PRIMARY KEY (`codi_cabfactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `codi_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `descri_categoria` varchar(25) NOT NULL,
  `esta_categoria` enum('A','I') NOT NULL,
  PRIMARY KEY (`codi_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`codi_categoria`, `descri_categoria`, `esta_categoria`) VALUES
(1, 'Damas', 'A'),
(2, 'Caballeros', 'A'),
(3, 'Niños', 'A'),
(4, 'Niñas', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color`
--

CREATE TABLE IF NOT EXISTS `color` (
  `codi_color` int(11) NOT NULL AUTO_INCREMENT,
  `descri_color` varchar(25) NOT NULL,
  `esta_color` enum('A','I') NOT NULL,
  PRIMARY KEY (`codi_color`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `color`
--

INSERT INTO `color` (`codi_color`, `descri_color`, `esta_color`) VALUES
(1, 'Rojo', 'A'),
(2, 'Azul', 'A'),
(3, 'Rojo', 'A'),
(4, 'Amarillo', 'A'),
(5, 'Rosado', 'A'),
(6, 'Morado', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_factura`
--

CREATE TABLE IF NOT EXISTS `detalle_factura` (
  `codi_cabfactura` int(11) NOT NULL,
  `secuencia_detfactura` int(11) NOT NULL,
  `cantidad_detfactura` int(11) NOT NULL,
  `subtotal_detfactura` decimal(4,2) NOT NULL,
  `codi_producto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE IF NOT EXISTS `marca` (
  `codi_marca` int(11) NOT NULL AUTO_INCREMENT,
  `descri_marca` varchar(25) NOT NULL,
  `esta_marca` enum('A','I') NOT NULL,
  PRIMARY KEY (`codi_marca`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`codi_marca`, `descri_marca`, `esta_marca`) VALUES
(1, 'Mar', 'A'),
(2, 'Rose', 'A'),
(3, 'Totto', 'A'),
(4, 'Tommy', 'A'),
(5, 'Adidas', 'A'),
(6, 'Nike', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `codi_producto` int(11) NOT NULL AUTO_INCREMENT,
  `descri_producto` varchar(25) NOT NULL,
  `codi_color` int(11) NOT NULL,
  `codi_talla` int(11) NOT NULL,
  `codi_marca` int(11) NOT NULL,
  `codi_categoria` int(11) NOT NULL,
  `esta_producto` enum('A','I') NOT NULL,
  `precio_producto` decimal(4,2) NOT NULL,
  `cant_producto` int(11) NOT NULL,
  PRIMARY KEY (`codi_producto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`codi_producto`, `descri_producto`, `codi_color`, `codi_talla`, `codi_marca`, `codi_categoria`, `esta_producto`, `precio_producto`, `cant_producto`) VALUES
(1, 'Camisa', 1, 1, 1, 1, 'I', '25.00', 8),
(2, 'camiseta', 1, 1, 1, 1, 'I', '15.00', 2),
(3, 'bolso', 1, 1, 1, 1, 'A', '3.90', 6),
(7, 'pantalon', 1, 1, 1, 1, 'A', '45.00', 5),
(9, 'pantalon', 2, 2, 2, 2, 'A', '79.00', 9),
(10, 'camiseta', 2, 2, 2, 2, 'A', '25.00', 45),
(11, 'Vestido', 2, 2, 2, 1, 'I', '67.00', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talla`
--

CREATE TABLE IF NOT EXISTS `talla` (
  `codi_talla` int(11) NOT NULL AUTO_INCREMENT,
  `descri_talla` varchar(25) NOT NULL,
  `esta_talla` enum('A','I') NOT NULL,
  PRIMARY KEY (`codi_talla`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `talla`
--

INSERT INTO `talla` (`codi_talla`, `descri_talla`, `esta_talla`) VALUES
(1, 'Mediana', 'A'),
(2, 'Grande', 'A'),
(3, 'Pequeña', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `codi_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `user_usuario` varchar(15) NOT NULL,
  `pass_usuario` varchar(15) NOT NULL,
  `esta_usuario` enum('A','I') NOT NULL,
  PRIMARY KEY (`codi_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`codi_usuario`, `user_usuario`, `pass_usuario`, `esta_usuario`) VALUES
(1, 'avictor', 'arv12', 'A'),
(2, 'iordonezs', 'ingris', 'A');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
