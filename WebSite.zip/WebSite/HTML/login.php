<?php //action = "AccesoDatos/inicioSesion.php" ?>

				<script type="text/javascript" src="../javascript/validacion.js"></script>


			<center>
				
				 <img src="../WebSite/Imagenes/usuario2.jpg" align="center" width="250" height="200"/></td>
				<p align="center"><font size="25" color="black">Inicion de Secion</font></p>
		</center>
	
		<form name="frm1" action="HTML/usuario_accion.php" method="post" >
		<input type="hidden" name="txt_accion" value="entrar" />
					
				 <table align="center" class="login">
				  
				   		<tr>
				   			<td>
				   				<label>User</label>
				   			</td>
				   			
				   			<td>
				   				<input type="text" name="txt_user" />
				   			</td>
				   		</tr>
				   		
				   		<tr>
				   			<td>
				   				<label>Password</label>
				   			</td>
				   			
				   			<td>
				   				<input type="password" name="txt_pass"/>
				   			</td>
				   		</tr>
				   		
				   		<tr>
				   			<th>
							<input type="button" onClick="Validar()" value="Entrar"/>
							</th>
				   		</tr>
				   			
				   			
				   </table>
		</form>
		
<script language="javascript">
	function Validar(){
		var nom = document.frm1.txt_user.value;
		var pwd = document.frm1.txt_pass.value;
		if(nom==''){
			alert('Ingrese un usuario');
			document.frm1.txt_user.focus();
			return false;
		}
		if(pwd==''){
			alert('Ingrese una clave personal');
			document.frm1.txt_pass.focus();
			return false;
		}
		document.frm1.submit();
	}
</script>
