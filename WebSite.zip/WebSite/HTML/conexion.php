<?php
	$cn_control= mysql_connect("mysql.nixiweb.com","u102764481_ingri","u102764481_ingri");
	if(!$cn_control){
		die('Error en la conexion: '.mysql_error());
	}
	if(!mysql_select_db("fucsia")){
		die("No existe la BD");
	}
?>