<?php

	require 'Conexion.php';
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$Descri =$_POST['txt_descripcion'];
		$Col=$_POST['color'];
		$Tall=$_POST['talla'];
		$Mar=$_POST['marca'];
		$Cat=$_POST['categoria'];
		$Pre=$_POST['txt_precio'];
		$Cant=$_POST['txt_cantidad'];
	
	
	
	$sql="insert into producto (descri_producto,codi_color,codi_talla,codi_marca,
	codi_categoria,esta_producto,precio_producto,cant_producto)
	values ('$Descri','$Col','$Tall','$Mar','$Cat','A','$Pre','$Cant')";
	$rsProdu = mysql_query($sql);
	
	if($rsProdu)
		echo "Registro Ingresado Correctamente";
	else
		echo "ERROR. Registro No Ingresado";
	}
?>