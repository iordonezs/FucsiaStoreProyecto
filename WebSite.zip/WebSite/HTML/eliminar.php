<?php

require 'conexion.php';

if(isset($_REQUEST['id'])){
	$id=$_REQUEST['id'];

	$sql="UPDATE producto SET esta_producto='I' WHERE codi_producto=$id";
	$rsCliente= mysql_query($sql);

	if(isset($rsCliente)){
		echo "Su registro ha sido eliminado";
	}else{
		echo "Su registro no ha sido eliminado";
	}
}
?>