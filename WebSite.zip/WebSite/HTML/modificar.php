<?php
	require 'Conexion.php';
	
	if(isset($_REQUEST['id'])){
		$id=$_REQUEST['id'];
		$Descri=$_POST['txt_descripcion'];
		$Col=$_POST['color'];
		$Tall=$_POST['talla'];
		$Mar=$_POST['marca'];
		$Cat=$_POST['categoria'];
		$Pre=$_POST['txt_precio'];
		$Cant=$_POST['txt_cantidad'];
		
		
		$sql="UPDATE producto SET descri_producto='$Descri',codi_color='$Col',codi_talla='$Tall',
				codi_marca='$Mar',codi_categoria='$Cat', precio_producto='$Pre',cant_producto='$Cant'
				 WHERE codi_producto='$id' and esta_producto='A'";
		$rsProducto= mysql_query($sql);
		
		if(isset($rsProducto)){
			echo "Su registro ha sido modificado";
		}else{
			echo "Su registro no ha sido modificado";
		}
	}	
?>