<?php
	require 'conexion.php';
	$sql="Select * from producto where esta_producto='A'";
	$rsProducto=mysql_query($sql);
	
	?>
	<html>
	<head>
		<title>CONSULTA</title>
	</head>
	
	
	<body>
	<table border="2">
		<tr> <th width="145">Descripcion</th> 
			 <th width="145">Color</th> 
		 	 <th width="135">Talla</th> 
		 	 <th width="135">Marca</th> 
			 <th width="135">Categoria</th> 
		 	 <th width="145">Estado</th> 
		 	 <th width="135">Precio</th> 
		 	 <th width="145">Cantidad</th> 
			 <th width="145">Opciones</th> 
		 </tr>	
	</table>
	
	
	<?php while($arrProducto=mysql_fetch_array($rsProducto)){?>
		<table border="2">
			<tr>
				<td width="155"><?php echo $arrProducto['descri_producto']?></td>
			
				<td width="155"><?php echo $arrProducto['codi_color']?></td>
		
				<td width="145"><?php echo $arrProducto['codi_talla']?></td>
				
				<td width="150"><?php echo $arrProducto['codi_marca']?></td>
				
				<td width="145"><?php echo $arrProducto['codi_categoria']?></td>
				
				<td width="150"><?php echo $arrProducto['esta_producto']?></td>
				
				<td width="150"><?php echo $arrProducto['precio_producto']?></td>
				
					<td width="150"><?php echo $arrProducto['cant_producto']?></td>
				
				<td width="150"><a title="modificar" href="ingreso.php?id=<?php echo $arrProducto['codi_producto']?>
				">Modificar</a> / 
					<a title="eliminar" href="eliminar.php?id=<?php echo $arrProducto['codi_producto']?>">Eliminar</a>
				
				</td>
			</tr>
		
		</table>
	</body>
<?php 
	}
?>

</html>