<?php
session_start();
require '../acceso/usuario.class.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	//Iniciar sesion
	if ($_POST['txt_accion'] == 'entrar'){
		$Usuario = $_POST['txt_user'];
		$Contrasena = $_POST['txt_pass'];
		
		$oUsuario = new Usuario;
		$resultado = $oUsuario->Iniciar_sesion($Usuario, $Contrasena);
		
			if ($resultado == true){
				$arrUsuario = mysql_fetch_array($resultado);
				$_SESSION['user'] = $arrUsuario['user_usuario'];	
				$_SESSION['userpass'] = $arrUsuario['pass_usuario'];
				//echo $_SESSION['user'] ;
				echo "<script language=javascript>
							alert('Bienvenido/a, ".$arrUsuario['user_usuario']."')
							self.location='../'
						</script>";
				
				//echo '<br>Variable de Sesion: '. $_SESSION['user'];
				//echo $mySQL.$Usuario. $Contrasena ;
			}else{
				echo "<script language=javascript>
							alert('Usuario o contraseña invalido')
						</script>";
			}
	}
	
	//Ingresa Usuario
	if ($_POST['txt_accion'] == 'insert'){
		$User = $_POST['txt_user'];
		$Pass = $_POST['txt_pass'];
		$Estado = $_POST['txt_estado'];
		
		
		$arrUsuario = array($User, $Pass, $Estado);
		
		$oUsuario = new Usuario;
		$resultado = $oUsuario->Usuario_insert($arrUsuario);
		
		if($resultado == true){
			//echo "OK - Registro Ingresado correctamente";
			echo '<script language=javascript>
		alert("OK - Registro Ingresado correctamente")
		self.location="../index.php"
		</script>';
		}
		else{
			echo '<script language=javascript>
		alert("X - ERROR. Registro no ingresado")
		self.location="../index.php"
		</script>';
		}
	
	}
	
	//Modifica Usuario
	if ($_POST['txt_accion'] == 'update'){
		$id = $_REQUEST['id'];
		$User = $_POST['txt_user'];
		$Pass = $_POST['txt_pass'];
		$Estado = $_POST['txt_estado'];
		
		$arrUsuario = array($id, $User, $Pass, $Estado);
		
		$oUsuario = new Usuario;
		$resultado = $oUsuario->Usuario_update($arrUsuario);
		
		// $SQL = "INSERT INTO usuario(usu_nombre, usu_apellido, usu_cedula, usu_edad, usu_sexo, ciu_codigo, usu_user, usu_pass, usu_estado)
				// VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
		
		// $rsUsuario = mysql_query($SQL);
		if($resultado == true){
			//echo "OK - Registro Ingresado correctamente";
			echo '<script language=javascript>
		alert("OK - Registro Actualizado correctamente")
		self.location="../index.php"
		</script>';
		}
		else{
			echo "X - ERROR. Registro no actualizado";
		}
	
	}
	
	
}

?>