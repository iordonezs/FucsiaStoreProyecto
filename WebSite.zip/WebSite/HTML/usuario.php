<?php
session_start(); ?>
				<script type="text/javascript" src="../javascript/validacion.js"></script>

<center>
		
		 <img src="../WebSite/Imagenes/usuario1.jpg" align="center" width="250" height="200"/></td>
		 <br>
		<p align="center"><font size="25" color="black">Usuario</font></p>
</center>

<form name="frm1" action="HTML/usuario_accion.php" method="post">
	<input type="hidden" name="txt_accion" value="insert" />
			
		 <table align="center">
		  
				<tr>
					<td>
						<label>User</label>
					</td>
					
					<td>
						<input type="text" name="txt_usuario" onkeypress="return soloLetras(event)"/>
					</td>
				</tr>
				
				<tr>
					<td>
						<label>Password</label>
					</td>
					
					<td>
						<input type="text" name="txt_contrasena" onkeypress="return soloLetras(event)"/>
					</td>
				</tr>
				
				<tr>
					<td>
						<label>Estado:</label>
					</td>
					
					<td>
						<input type="text" name="txt_estado" onkeypress="return soloLetras(event)"/>
					</td>
				</tr>
				

				<tr>
					<td>
						<input align="center" type="submit" value="Enviar"/>
					</td>
				</tr>
					
		   </table>
</form>
</table>


