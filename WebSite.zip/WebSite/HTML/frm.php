<?php 

require'../acceso/conexion.class.php';


$sql = "select *from color";
$rsColor = mysql_query($sql);

$sql = "select *from categoria";
$rsCategoria = mysql_query($sql);

$sql = "select *from marca";
$rsMarca = mysql_query($sql);

$sql = "select *from talla";
$rsTalla = mysql_query($sql);


if (isset($_REQUEST['id'])){
	
	$sql = "select * from producto where esta_producto ='A' and codi_producto = ".$_REQUEST['id'];
	$rsProducto = mysql_query($sql);
	$arrProducto = mysql_fetch_array($rsProducto);
}
?>

<form name="frm1" action = 
<?php if (isset($_REQUEST['id']))
					{echo "modificar.php?id=".$_REQUEST['id'];}
					else{echo "ingreso.php";}?>
					" method="post">

<input type="hidden" name="txt_accion" value="entrar" />
	
	
    	<th>Ingreso de Producto</th>
    

    
			Descripcion:
			<input type="text" name="txt_descripcion" value ="<?php 
			if (isset($_REQUEST['id'])){echo $arrProducto['descri_producto'];}?>">
			
		<br>
			Color:<select name="cboColor">
			
			<?php 
				while ($arrcolor = mysql_fetch_array($rsColor)){	
					
					echo "<option value= '".$arrColor['codi_color']."' ";
					
										if (isset($_REQUEST['id'])){
						if ($arrProducto['codi_color']==$arrColor['codi_color']){
							echo "selected";
						}
					}
					
					echo ">".$arrColor['descri_color']."</option>";
				} 
			?>
			
		</select>
		
			
    
	
	
    	
			Talla:
			<br>
			<select name="cboTalla">
			<?php 
				while ($arrTalla = mysql_fetch_array($rsTalla)){	
					
					echo "<option value= '".$arrTalla['codi_talla']."' ";
					
										if (isset($_REQUEST['id'])){
						if ($arrProducto['codi_talla']==$arrTalla['codi_talla']){
							echo "selected";
						}
					}
					
					echo ">".$arrTalla['descri_talla']."</option>";
				} 
			?>
			
		</select>	
	
			Marca:
			<br>
		<select name="cboMarca">
			<?php 
				while ($arrMarca = mysql_fetch_array($rsMarca)){	
					
					echo "<option value= '".$arrMarca['codi_marca']."' ";
					
										if (isset($_REQUEST['id'])){
						if ($arrProducto['codi_marca']==$arrMarca['codi_marca']){
							echo "selected";
						}
					}
					
					echo ">".$arrTalla['descri_marca']."</option>";
				} 
			?>
			
		</select>	

			Categoria:
			<br>
	<select name="cboCategoria">
			<?php 
				while ($arrCategoria = mysql_fetch_array($rsCategoria)){	
					
					echo "<option value= '".$arrCategoria['codi_categoria']."' ";
					
										if (isset($_REQUEST['id'])){
						if ($arrProducto['codi_categoria']==$arrCategoria['codi_categoria']){
							echo "selected";
						}
					}
					
					echo ">".$arrCategoria['descri_categoria']."</option>";
				} 
			?>
			
		</select>	
<br>
			Precio:
			<input type="text" name="txt_precio" value="<?php
					if (isset($_REQUEST['id'])){
					echo $arrProducto['precio_producto'];
					}
					?>">
		<br>
			Cantidad:
			<input type="text" name="txt_cantidad" value="<?php
					if (isset($_REQUEST['id'])){
					echo $arrProducto['cant_producto'];
					}
					?>">
		
    	<th>
			<input type="submit" value="Enviar">
        </th>
    </tr>
 
</table>

</form>