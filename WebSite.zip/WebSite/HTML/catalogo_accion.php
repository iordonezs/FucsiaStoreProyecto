<?php



require '../acceso/usuario.class.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	//Ingresa producto
	if ($_POST['txt_accion'] == 'insert'){
		
		$descripcion = $_POST['txt_descripcion'];
		$color = $_POST['txt_color'] ;
		$talla = $_POST['txt_talla'];
		$marca = $_POST['txt_marca']; 
		$categoria = $_POST['txt_categoria']; 
		$estado = $_POST['txt_estado'];
		$precio = $_POST['txt_precio'];
		$cantidad =$_POST['txt_cantidad']; 
		
		
		$arrProducto = array($descripcion, $color, $talla,$marca,$categoria,$estado,$precio,$cantidad);
		
		$oUsuario = new Usuario;
		$resultado = $oUsuario->Usuario_insert($arrUsuario);
		
		if($resultado == true){
			//echo "OK - Registro Ingresado correctamente";
			echo '<script language=javascript>
		alert("OK - Registro Ingresado correctamente")
		self.location="../index.php"
		</script>';
		}
		else{
			echo '<script language=javascript>
		alert("X - ERROR. Registro no ingresado")
		self.location="../index.php"
		</script>';
		}
	
	}
	
	//Modifica Usuario
	if ($_POST['txt_accion'] == 'update'){
	
		$id = $_REQUEST['id'];
		$descripcion = $_POST['txt_descripcion'];
		$color = $_POST['txt_color'] ;
		$talla = $_POST['txt_talla'];
		$marca = $_POST['txt_marca']; 
		$categoria = $_POST['txt_categoria']; 
		$estado = $_POST['txt_estado'];
		$precio = $_POST['txt_precio'];
		$cantidad =$_POST['txt_cantidad']; 
		
		$arrUsuario = array($id,$descripcion, $color, $talla,$marca,$categoria,$estado,$precio,$cantidad);
		
		$oUsuario = new Usuario;
		$resultado = $oUsuario->Usuario_update($arrUsuario);
		
		// $SQL = "INSERT INTO usuario(usu_nombre, usu_apellido, usu_cedula, usu_edad, usu_sexo, ciu_codigo, usu_user, usu_pass, usu_estado)
				// VALUES ('$Nombre','$Apellido','$Cedula',$Edad,'$Sexo',$Ciudad,'$Usuario','$Pass','A')";
		
		// $rsUsuario = mysql_query($SQL);
		if($resultado == true){
			//echo "OK - Registro Ingresado correctamente";
			echo '<script language=javascript>
		alert("OK - Registro Actualizado correctamente")
		self.location="../index.php"
		</script>';
		}
		else{
			echo "X - ERROR. Registro no actualizado";
		}
	
	}
	
	
}

?>