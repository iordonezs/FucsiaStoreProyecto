<?php
//session_start(); 

	//require '../acceso/conexion.class.php';
	require 'conexion.php';
	$sql = "select * from color where esta_color='A'";
	$rsColor = mysql_query($sql);

$sql = "select *from categoria where esta_categoria='A'";
$rsCategoria = mysql_query($sql);

$sql = "select *from marca where esta_marca='A'";
$rsMarca = mysql_query($sql);

$sql = "select *from talla where esta_talla='A'";
$rsTalla = mysql_query($sql);

	$male_status = 'unchecked';
	$female_status = 'unchecked';
	if (isset($_REQUEST['id'])){
		$sql ="select * from producto where esta_producto = 'A' and codi_producto =".$_REQUEST['id'];
		$rsProducto = mysql_query($sql);
		$arrProducto = mysql_fetch_array($rsProducto);
	}
?>
	
	
<html>
	<head>
	
		<title>Ingreso</title>
		
	</head>
	<body>
	
		<form name="frm2"
			<?php if (isset($_REQUEST["id"])) {?>
				action="modificar.php?id=<?php echo  $arrProducto['codi_producto'] ?>"
					<?php }else {?>
						action="Registro.php"						
					<?php }
			?>method="post" >
			<table align="center" border="2" width="500">
			<tr>
			<td>Descripcion:</td><td> <input type="text" name="txt_descripcion" value = "<?php if(isset($arrProducto['descri_producto'])) echo $arrProducto['descri_producto']; ?>"></td><br>
			</tr>
			<tr>
			<td>Color:</td><td> <select name="color">
						<?php 
							while ($arrColor= mysql_fetch_array($rsColor)){
						?>
						<option value="<?php echo $arrColor['codi_color'];?>"
						
								<?php if (isset($_REQUEST['id'])){
											if($arrProducto['codi_color'] == $arrColor['codi_color']){
									echo 'selected';} 
									else echo '';}?>>
									<?php echo $arrColor['descri_color'];?></option>
					<?php } ?>
					</td>
					</tr>
					</select><br>
		<tr>
		<td>Talla: </td><td><select name="talla">
						<?php 
							while ($arrTalla= mysql_fetch_array($rsTalla)){
						?>
						<option value="<?php echo $arrTalla['codi_talla'];?>"
								<?php if (isset($arrProducto['codi_talla'])){
											if($arrProducto['codi_talla'] == $arrTalla['codi_talla']){
									echo 'selected';} 
									else echo '';}?>
						><?php echo $arrTalla['descri_talla'];?></option>
					<?php } ?>
					</select><br>	
						</td>
						</tr>
					
					
				<tr>	
			<td>Marca:</td><td> <select name="marca">
						<?php 
							while ($arrMarca= mysql_fetch_array($rsMarca)){
						?>
						<option value="<?php echo $arrMarca['codi_marca'];?>"
								<?php if (isset($arrProducto['codi_marca'])){
											if($arrProducto['codi_marca'] == $arrMarca['codi_marca']){
									echo 'selected';} 
									else echo '';}?>>
									<?php echo $arrMarca['descri_marca'];?></option>
					<?php } ?>
					</select><br>
					</td>
					</tr>
					<tr>
			<td>Categoria:</td><td> <select name="categoria">
						<?php 
							while ($arrCategoria= mysql_fetch_array($rsCategoria)){
						?>
						<option value="<?php echo $arrCategoria['codi_categoria'];?>"
								<?php if (isset($arrProducto['codi_categoria'])){
											if($arrProducto['codi_categoria'] == $arrCategoria['codi_categoria']){
									echo 'selected';} 
									else echo '';}?>
						><?php echo $arrCategoria['descri_categoria'];?></option>
					<?php } ?>
					</select><br>
					</td>
					</tr>
					<tr>
				
			<td>Precio: </td><td><input type="text" name="txt_precio" value = "<?php if(isset($arrProducto['precio_producto'])) echo $arrProducto['precio_producto']; ?>"></td></tr>
			<tr>
			
			<td>Cantidad: </td><td><input type="text" name="txt_cantidad" value = "<?php if(isset($arrProducto['cant_producto'])) echo $arrProducto['cant_producto']; ?>"> </td> </tr><br>
			
			
			<br>
			<tr >
			<td colspan="2" align="center">
		<input type="button" value="Enviar" onClick="Validar()"></td></tr>
		</table>
		</form>
		
		<script language="javascript">
	function Validar(){
		var des = document.frm2.txt_descripcion.value;
		var pre = document.frm2.txt_precio.value;
		var cant = document.frm2.txt_cantidad.value;
		if(des==''){
			alert('Ingrese una descripcion');
			document.frm2.txt_descripcion.focus();
			return false;
		}
		if(pre==''){
			alert('Ingrese un precio');
			document.frm2.txt_precio.focus();
			return false;
		}
		if(cant==''){
			alert('Ingrese una cantidad');
			document.frm2.txt_cantidad.focus();
			return false;
		}
		document.frm2.submit();
	}
</script>
		
	</body>
</html>